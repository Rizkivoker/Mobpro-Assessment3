package org.d3if3168.appassessment3.system.database

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.d3if3168.appassessment3.system.database.model.Contact
import org.d3if3168.appassessment3.system.network.ContactAPI
import org.d3if3168.appassessment3.system.network.ContactStatus
import java.io.ByteArrayOutputStream

class MainViewModel : ViewModel() {

        private val _contactData = MutableLiveData<List<Contact>>()
        val contactData: LiveData<List<Contact>> get() = _contactData

        var contactStatus = MutableStateFlow(ContactStatus.LOADING)

        fun addContact(email: String, contactName: String, contactPhone: String, contactEmail: String, contactBirthday: String, image: Bitmap?) {
            viewModelScope.launch(Dispatchers.IO) {
                contactStatus.value = ContactStatus.LOADING
                try {
                    val emailPart = email.toRequestBody("text/plain".toMediaTypeOrNull())
                    val contactNamePart = contactName.toRequestBody("text/plain".toMediaTypeOrNull())
                    val contactPhonePart = contactPhone.toRequestBody("text/plain".toMediaTypeOrNull())
                    val contactEmailPart = contactEmail.toRequestBody("text/plain".toMediaTypeOrNull())
                    val contactBirthdayPart = contactBirthday.toRequestBody("text/plain".toMediaTypeOrNull())

                    val imagePart: MultipartBody.Part? = image?.let {
                        val byteArrayOutputStream = ByteArrayOutputStream()
                        it.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream)
                        val requestBody = RequestBody.create("image/jpeg".toMediaTypeOrNull(), byteArrayOutputStream.toByteArray())
                        MultipartBody.Part.createFormData("contactImageUrl", "image.jpg", requestBody)
                    }

                    val response = ContactAPI.retrofitService.addContact(
                        emailPart, contactNamePart, contactPhonePart, contactEmailPart, contactBirthdayPart, imagePart
                    )

                    _contactData.postValue(response.results)
                    contactStatus.value = ContactStatus.SUCCESS
                } catch (e: Exception) {
                    contactStatus.value = ContactStatus.FAILED
                }
            }
        }

        fun getContacts() {
            viewModelScope.launch(Dispatchers.IO) {
                contactStatus.value = ContactStatus.LOADING
                try {
                    val response = ContactAPI.retrofitService.getContacts()
                    _contactData.postValue(response.results)
                    contactStatus.value = ContactStatus.SUCCESS
                } catch (e: Exception) {
                    contactStatus.value = ContactStatus.FAILED
                }
            }
        }

        fun deleteContact(id: String) {
            viewModelScope.launch(Dispatchers.IO) {
                contactStatus.value = ContactStatus.LOADING
                try {
                    val response = ContactAPI.retrofitService.deleteContact(id)
                    _contactData.postValue(response.results)
                    contactStatus.value = ContactStatus.SUCCESS
                } catch (e: Exception) {
                    contactStatus.value = ContactStatus.FAILED
                }
            }
        }
    }