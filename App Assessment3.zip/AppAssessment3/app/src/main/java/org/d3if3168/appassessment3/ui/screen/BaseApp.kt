package org.d3if3168.appassessment3.ui.screen

import android.content.Context
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.d3if3168.appassessment3.R
import org.d3if3168.appassessment3.system.database.MainViewModel
import org.d3if3168.appassessment3.system.database.model.User
import org.d3if3168.appassessment3.system.network.UserDataStore
import org.d3if3168.appassessment3.system.network.signIn
import org.d3if3168.appassessment3.system.network.signOut
import org.d3if3168.appassessment3.system.util.SettingsDataStore
import org.d3if3168.appassessment3.ui.theme.AppAssessment3Theme
import org.d3if3168.appassessment3.ui.widget.ProfilDialog
import org.d3if3168.appassessment3.ui.widget.TopAppBarWidget

@Composable
fun BaseApp(
    navController: NavHostController,
    onNavigateToScreen : (String, String, String) -> Unit,
) {
    val context = LocalContext.current
    val dataStore = SettingsDataStore(context)
    val viewModel: MainViewModel = viewModel()
    val userStore = UserDataStore(context)
    val appTheme by dataStore.layoutFlow.collectAsState(true)
    var showDialog by remember { mutableStateOf(false) }
    val user by userStore.userFlow.collectAsState(User())
    AppAssessment3Theme(darkTheme = appTheme) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            topBar = {
                TopAppBarWidget(
                    title = stringResource(id = R.string.app_name),
                    user = user,
                    appTheme = appTheme,
                    showDialog = showDialog,
                    onShowDialogChange = { showDialog = it },
                    onAppThemeChange = { newTheme ->
                        CoroutineScope(Dispatchers.IO).launch {
                            dataStore.saveLayout(!appTheme)
                        }
                    }
                )
            },
            bottomBar = {
                //BottomBarWidget(navController)
            },
        ) { paddingValues ->
            ScreenContent(
                onClick = { /*TODO*/ },
                viewModel = viewModel,
                modifier = Modifier.padding(paddingValues),
                navController = navController,
                onNavigateToScreen
            )
            //NavigationGraph(navController, apiProfile, modifier = Modifier.padding(paddingValues))

            // LaunchedEffect to handle sign-in if needed
            LaunchedEffect(showDialog) {
                if (showDialog && user.email.isEmpty()) {
                    CoroutineScope(Dispatchers.IO).launch {
                        signIn(context, userStore)
                    }
                }
            }

            // Display the dialog if showDialog is true
            if (showDialog && user.email.isNotEmpty()) {
                ProfilDialog(user = user, onDismissRequest = { showDialog = false }) {
                    CoroutineScope(Dispatchers.IO).launch {
                        signOut(context, userStore)
                    }
                    showDialog = false
                }
            }
        }
    }
}

@Composable
fun ScreenContent(
    onClick: () -> Unit,
    viewModel: MainViewModel,
    modifier: Modifier,
    navController: NavHostController,
    onNavigateToScreen : (String, String, String) -> Unit,
    ) {

    LazyVerticalGrid(
        modifier = modifier
            .fillMaxSize()
            .padding(4.dp),
        columns = GridCells.Fixed(2),
    ) {
        item {
            ListItem(navController, onNavigateToScreen)
        }
        item {
            ListItem(navController, onNavigateToScreen)
        }
        item {
            ListItem(navController, onNavigateToScreen)
        }
        item {
            ListItem(navController, onNavigateToScreen)
        }
    }
}

@Composable
fun ListItem(
    navController: NavHostController,
    onNavigateToScreen: (String, String, String) -> Unit
) {
    var nama by remember { mutableStateOf("Andre") }
    var alamat by remember { mutableStateOf("Jalan Suryalaya Baru no 16") }
    var nomor by remember { mutableStateOf("082584726473") }

    Box(
        modifier = Modifier
            .clickable {
                onNavigateToScreen(nama, alamat, nomor)
            }
            .padding(4.dp)
            .border(1.dp, Color.Gray),
        contentAlignment = Alignment.BottomCenter
    ) {
        Image(
            painter = painterResource(id = R.drawable.baseline_broken_image_24),
            contentDescription = "",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .aspectRatio(1f)
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .background(Color(red = 0f, green = 0f, blue = 0f, alpha = 0.5f))
                .padding(4.dp)
        ) {
            Text(
                text = nama,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = alamat,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = nomor,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AppAssessment3Theme {
        BaseApp(rememberNavController()){ nama, alamat, nomor ->

        }
    }
}